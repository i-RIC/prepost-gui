#include "continuouscolormapper.h"
#include "private/continuouscolormapper_impl.h"

namespace guimisc {
namespace colormapper {

class SpecHandler
{
public:
	virtual ~SpecHandler() {}
	virtual QColor convertSpec(const QColor& color) const = 0;
	QColor interpolate(double v, double v1, const QColor& c1, double v2, const QColor& c2) const;
	static double interpolate(double x, double x1, double y1, double x2, double y2);

	virtual double param1(const QColor& c) const = 0;
	virtual double param2(const QColor& c) const = 0;
	virtual double param3(const QColor& c) const = 0;
	virtual double param4(const QColor& c) const = 0;
	virtual QColor color(double p1, double p2, double p3, double p4) const = 0;

	virtual SpecHandler* clone() const = 0;
};

class RgbHandler : public SpecHandler
{
public:
	RgbHandler() {}
	QColor convertSpec(const QColor &color) const override {
		return color.toRgb();
	}
	double param1(const QColor &c) const override {
		return c.redF();
	}
	double param2(const QColor &c) const override {
		return c.greenF();
	}
	double param3(const QColor &c) const override {
		return c.blueF();
	}
	double param4(const QColor &) const override {
		return 0;
	}
	QColor color(double p1, double p2, double p3, double) const override
	{
		QColor ret;
		ret.setRgbF(p1, p2, p3);

		return ret;
	}
	SpecHandler* clone() const override
	{
		return new RgbHandler();
	}
};

class HsvHandler : public SpecHandler
{
public:
	QColor convertSpec(const QColor &color) const override {
		return color.toHsv();
	}
	double param1(const QColor &c) const override {
		return c.hsvHueF();
	}
	double param2(const QColor &c) const override {
		return c.hsvSaturationF();
	}
	double param3(const QColor &c) const override {
		return c.valueF();
	}
	double param4(const QColor &) const override {
		return 0;
	}
	QColor color(double p1, double p2, double p3, double) const override
	{
		QColor ret(QColor::Hsv);
		ret.setHsvF(p1, p2, p3);

		return ret;
	}
	SpecHandler* clone() const override
	{
		return new HsvHandler();
	}
};

class CmykHandler : public SpecHandler
{
public:
	QColor convertSpec(const QColor &color) const override {
		return color.toCmyk();
	}
	double param1(const QColor &c) const override {
		return c.cyanF();
	}
	double param2(const QColor &c) const override {
		return c.magentaF();
	}
	double param3(const QColor &c) const override {
		return c.yellowF();
	}
	double param4(const QColor &c) const override {
		return c.blackF();
	}
	QColor color(double p1, double p2, double p3, double p4) const override
	{
		QColor ret(QColor::Hsv);
		ret.setCmykF(p1, p2, p3, p4);

		return ret;
	}
	SpecHandler* clone() const override
	{
		return new CmykHandler();
	}
};

class HslHandler : public SpecHandler
{
public:
	QColor convertSpec(const QColor &color) const override {
		return color.toHsl();
	}
	double param1(const QColor &c) const override {
		return c.hslHueF();
	}
	double param2(const QColor &c) const override {
		return c.hslSaturationF();
	}
	double param3(const QColor &c) const override {
		return c.lightnessF();
	}
	double param4(const QColor &) const override {
		return 0;
	}
	QColor color(double p1, double p2, double p3, double) const override
	{
		QColor ret(QColor::Hsl);
		ret.setHslF(p1, p2, p3);

		return ret;
	}
	SpecHandler* clone() const override
	{
		return new HslHandler();
	}
};

QColor SpecHandler::interpolate(double v, double v1, const QColor& c1, double v2, const QColor& c2) const
{
	double p1 = interpolate(v, v1, param1(c1), v2, param1(c2));
	double p2 = interpolate(v, v1, param2(c1), v2, param2(c2));
	double p3 = interpolate(v, v1, param3(c1), v2, param3(c2));
	double p4 = interpolate(v, v1, param4(c1), v2, param4(c2));

	return color(p1, p2, p3, p4);
}

double SpecHandler::interpolate(double x, double x1, double y1, double x2, double y2)
{
	// @todo implement this using LinearInterpolator1D1
	return 0;
}

ContinuousColorMapper::Impl::Impl(QColor::Spec spec) :
	m_outOfRangeMode (UseLimitColor),
	m_defaultColor (Qt::white)
{
	switch (spec) {
	case QColor::Rgb:
		m_specHandler = new RgbHandler();
		break;
	case QColor::Hsv:
		m_specHandler = new HsvHandler();
		break;
	case QColor::Cmyk:
		m_specHandler = new CmykHandler();
		break;
	case QColor::Hsl:
		m_specHandler = new HslHandler();
		break;
	default:
		m_specHandler = new RgbHandler();
		break;
	}
}

ContinuousColorMapper::Impl::Impl(const Impl& impl) :
	m_specHandler (impl.m_specHandler->clone()),
	m_colorMap (impl.m_colorMap),
	m_outOfRangeMode {impl.m_outOfRangeMode},
	m_defaultColor {impl.m_defaultColor}
{}

ContinuousColorMapper::Impl::~Impl()
{
	delete m_specHandler;
}

ContinuousColorMapper::Impl& ContinuousColorMapper::Impl::operator=(const Impl& impl)
{
	delete m_specHandler;
	m_specHandler = impl.m_specHandler->clone();

	m_colorMap = impl.m_colorMap;
	m_outOfRangeMode = impl.m_outOfRangeMode;
	m_defaultColor = impl.m_defaultColor;

	return *this;
}

// public interfaces

ContinuousColorMapper::ContinuousColorMapper() :
	ContinuousColorMapper(QColor::Hsv)
{}

ContinuousColorMapper::ContinuousColorMapper(QColor::Spec spec) :
	m_impl (new Impl(spec))
{}

ContinuousColorMapper::ContinuousColorMapper(const ContinuousColorMapper& mapper) :
	m_impl(new Impl(*mapper.m_impl))
{}

ContinuousColorMapper::ContinuousColorMapper(ContinuousColorMapper&& mapper) :
	m_impl (mapper.m_impl)
{
	mapper.m_impl = nullptr;
}

ContinuousColorMapper::~ContinuousColorMapper()
{
	delete m_impl;
}

QColor ContinuousColorMapper::map(double value) const
{
	if (m_impl->m_colorMap.size() == 0) {return m_impl->m_defaultColor;}

	auto lb = m_impl->m_colorMap.lower_bound(value);
	auto ub = m_impl->m_colorMap.upper_bound(value);

	QColor ret;
	if (lb == m_impl->m_colorMap.end()) {
		// value is smaller than the smallest value.
		if (m_impl->m_outOfRangeMode == UseLimitColor) {
			ret = m_impl->m_colorMap.begin()->second;
		} else if (m_impl->m_outOfRangeMode == UseDefaultColor) {
			ret = m_impl->m_defaultColor;
		}
	} else if (ub == m_impl->m_colorMap.end()) {
		if (value == m_impl->m_colorMap.rbegin()->first) {
			// value is just the biggest value
			ret = m_impl->m_colorMap.rbegin()->second;
		} else {
			// value is bigger than the biggest value.
			if (m_impl->m_outOfRangeMode == UseLimitColor) {
				ret = m_impl->m_colorMap.rbegin()->second;
			} else if (m_impl->m_outOfRangeMode == UseDefaultColor) {
				ret = m_impl->m_defaultColor;
			}
		}
	} else {
		ret = m_impl->m_specHandler->interpolate(value, lb->first, lb->second, ub->first, ub->second);
	}

	return ret.toRgb();
}

std::vector<double> ContinuousColorMapper::values() const
{
	std::vector<double> ret;
	for (auto pair : m_impl->m_colorMap) {
		ret.push_back(pair.first);
	}
	return ret;
}

double ContinuousColorMapper::minValue() const
{
	return m_impl->m_colorMap.begin()->first;
}

double ContinuousColorMapper::maxValue() const
{
	return m_impl->m_colorMap.rbegin()->first;
}

OutOfRangeMode ContinuousColorMapper::outOfRangeMode() const
{
	return m_impl->m_outOfRangeMode;
}

void ContinuousColorMapper::setOutOfRangeMode(OutOfRangeMode mode)
{
	m_impl->m_outOfRangeMode = mode;
}

QColor ContinuousColorMapper::defaultColor() const
{
	return m_impl->m_defaultColor;
}

void ContinuousColorMapper::setDefaultColor(const QColor& c)
{
	m_impl->m_defaultColor = c;
}

void ContinuousColorMapper::add(double value, const QColor& color)
{
	m_impl->m_colorMap.insert({value, color});
}

void ContinuousColorMapper::remove(double value)
{
	auto it = m_impl->m_colorMap.find(value);
	if (it == m_impl->m_colorMap.end()) {return;}

	m_impl->m_colorMap.erase(it);
}

void ContinuousColorMapper::clear()
{
	m_impl->m_colorMap.clear();
}

ContinuousColorMapper& ContinuousColorMapper::operator=(const ContinuousColorMapper& mapper)
{
	*m_impl = *(mapper.m_impl);

	return *this;
}

ContinuousColorMapper& ContinuousColorMapper::operator=(ContinuousColorMapper&& mapper)
{
	m_impl = mapper.m_impl;
	mapper.m_impl = nullptr;

	return *this;
}

} // colormapper
} // guimisc
