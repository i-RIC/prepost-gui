#include "discontinuouscolormapper.h"
#include "private/discontinuouscolormapper_impl.h"

#include <algorithm>

using namespace guimisc::colormapper;

DiscontinuousColorMapper::Impl::Impl() :
	m_outOfRangeMode (UseLimitColor),
	m_defaultColor (Qt::white)
{}

DiscontinuousColorMapper::Impl::~Impl()
{}

// public interfaces

DiscontinuousColorMapper::DiscontinuousColorMapper() :
	m_impl (new Impl())
{}

DiscontinuousColorMapper::DiscontinuousColorMapper(const DiscontinuousColorMapper& mapper) :
	m_impl (new Impl(*mapper.m_impl))
{}

DiscontinuousColorMapper::DiscontinuousColorMapper(DiscontinuousColorMapper&& mapper) :
	m_impl (mapper.m_impl)
{
	mapper.m_impl = nullptr;
}

DiscontinuousColorMapper::~DiscontinuousColorMapper()
{
	delete m_impl;
}

QColor DiscontinuousColorMapper::map(double value) const
{
	if (m_impl->m_values.size() < 2) {return m_impl->m_defaultColor;}

	auto lb = std::lower_bound(m_impl->m_values.begin(), m_impl->m_values.end(), value);
	auto ub = std::upper_bound(m_impl->m_values.begin(), m_impl->m_values.end(), value);

	QColor ret;
	if (lb == m_impl->m_values.end()) {
		// value is smaller than the smallest value.
		if (m_impl->m_outOfRangeMode == UseLimitColor) {
			ret = m_impl->m_colors.front();
		} else if (m_impl->m_outOfRangeMode == UseDefaultColor) {
			ret = m_impl->m_defaultColor;
		}
	} else if (ub == m_impl->m_values.end()) {
		if (value == *(m_impl->m_values.rbegin())) {
			// value is just the biggest value
			ret = *(m_impl->m_colors.rbegin());
		} else {
			// value is bigger than the biggest value.
			if (m_impl->m_outOfRangeMode == UseLimitColor) {
				ret = *(m_impl->m_colors.rbegin());
			} else if (m_impl->m_outOfRangeMode == UseDefaultColor) {
				ret = m_impl->m_defaultColor;
			}
		}
	} else {
		auto index = (lb - m_impl->m_values.begin());
		ret = m_impl->m_colors.at(index);
	}
	return ret.toRgb();
}

double DiscontinuousColorMapper::minValue() const
{
	if (m_impl->m_values.size() == 0) {return 0;}
	return m_impl->m_values[0];
}

double DiscontinuousColorMapper::maxValue() const
{
	if (m_impl->m_values.size() == 0) {return 0;}
	return m_impl->m_values[m_impl->m_values.size() - 1];
}

std::vector<double> DiscontinuousColorMapper::values() const
{
	return m_impl->m_values;
}

OutOfRangeMode DiscontinuousColorMapper::outOfRangeMode() const
{
	return m_impl->m_outOfRangeMode;
}

void DiscontinuousColorMapper::setOutOfRangeMode(OutOfRangeMode mode)
{
	m_impl->m_outOfRangeMode = mode;
}

QColor DiscontinuousColorMapper::defaultColor() const
{
	return m_impl->m_defaultColor;
}

void DiscontinuousColorMapper::setDefaultColor(const QColor& c)
{
	m_impl->m_defaultColor = c;
}

void DiscontinuousColorMapper::setMinValue(double minValue)
{
	clear();
	m_impl->m_values.push_back(minValue);
}

void DiscontinuousColorMapper::addRange(double value, const QColor& color)
{
	m_impl->m_values.push_back(value);
	m_impl->m_colors.push_back(color);
}

void DiscontinuousColorMapper::clear()
{
	m_impl->m_values.clear();
	m_impl->m_colors.clear();
}

DiscontinuousColorMapper& DiscontinuousColorMapper::operator=(const DiscontinuousColorMapper& mapper)
{
	*m_impl = *(mapper.m_impl);

	return *this;
}

DiscontinuousColorMapper& DiscontinuousColorMapper::operator=(DiscontinuousColorMapper&& mapper)
{
	m_impl = mapper.m_impl;
	mapper.m_impl = nullptr;

	return *this;
}
