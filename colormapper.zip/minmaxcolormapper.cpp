#include "minmaxcolormapper.h"
#include "private/minmaxcolormapper_impl.h"

using namespace guimisc::colormapper;

MinMaxColorMapper::Impl::Impl(QColor::Spec spec, const QColor& minColor, const QColor& maxColor) :
	m_minValue(0), m_maxValue(1),
	m_minColor(minColor), m_maxColor(maxColor),
	m_mapper {new ContinuousColorMapper(spec)}
{}

MinMaxColorMapper::Impl::Impl(const Impl& impl) :
	m_minValue (impl.m_minValue),
	m_maxValue (impl.m_maxValue),
	m_minColor (impl.m_minColor),
	m_maxColor (impl.m_maxColor),

	m_mapper (new ContinuousColorMapper(*(impl.m_mapper))),

	m_outOfRangeMode {UseLimitColor},
	m_defaultColor (Qt::white)
{}

MinMaxColorMapper::Impl::~Impl()
{
	delete m_mapper;
}

void MinMaxColorMapper::Impl::update()
{
	m_mapper->clear();
	m_mapper->add(m_minValue, m_maxColor);
	m_mapper->add(m_maxValue, m_maxColor);
}

MinMaxColorMapper::Impl& MinMaxColorMapper::Impl::operator=(const Impl& impl)
{
	m_minValue = impl.m_minValue;
	m_maxValue = impl.m_maxValue;
	m_minColor = impl.m_minColor;
	m_maxColor = impl.m_maxColor;

	delete m_mapper;
	m_mapper = new ContinuousColorMapper(*(impl.m_mapper));

	m_outOfRangeMode = impl.m_outOfRangeMode;
	m_defaultColor = impl.m_defaultColor;

	return *this;
}

// public interfaces
MinMaxColorMapper::MinMaxColorMapper(QColor::Spec spec, const QColor& colorMin, const QColor& colorMax) :
	MinMaxColorMapper(0, 1, spec, colorMin, colorMax)
{}

MinMaxColorMapper::MinMaxColorMapper(double min, double max, QColor::Spec spec, const QColor& colorMin, const QColor& colorMax) :
	m_impl {new Impl(spec, colorMin, colorMax)}
{
	setMinValue(min);
	setMaxValue(max);
}

MinMaxColorMapper::MinMaxColorMapper(const MinMaxColorMapper& mapper) :
	m_impl (new Impl(*mapper.m_impl))
{}

MinMaxColorMapper::MinMaxColorMapper(MinMaxColorMapper&& mapper) :
	m_impl (mapper.m_impl)
{
	mapper.m_impl = nullptr;
}

MinMaxColorMapper::~MinMaxColorMapper()
{
	delete m_impl;
}

QColor MinMaxColorMapper::map(double value) const
{
	return m_impl->m_mapper->map(value);
}

QColor MinMaxColorMapper::defaultColor() const
{
	return m_impl->m_defaultColor;
}

double MinMaxColorMapper::minValue() const
{
	return m_impl->m_minValue;
}

double MinMaxColorMapper::maxValue() const
{
	return m_impl->m_maxValue;
}

void MinMaxColorMapper::setMinValue(double min)
{
	m_impl->m_minValue = min;
	m_impl->update();
}

void MinMaxColorMapper::setMaxValue(double max)
{
	m_impl->m_maxValue = max;
	m_impl->update();
}

OutOfRangeMode MinMaxColorMapper::outOfRangeMode() const
{
	return m_impl->m_outOfRangeMode;
}

void MinMaxColorMapper::setOutOfRangeMode(OutOfRangeMode mode)
{
	m_impl->m_outOfRangeMode = mode;
}

void MinMaxColorMapper::setDefaultColor(const QColor& c)
{
	m_impl->m_defaultColor = c;
}

MinMaxColorMapper& MinMaxColorMapper::operator=(const MinMaxColorMapper& mapper)
{
	*m_impl = *(mapper.m_impl);

	return *this;
}

MinMaxColorMapper& MinMaxColorMapper::operator=(MinMaxColorMapper&& mapper)
{
	m_impl = mapper.m_impl;
	mapper.m_impl = nullptr;

	return *this;
}
