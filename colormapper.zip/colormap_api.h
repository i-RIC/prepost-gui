#ifndef COLORMAP_API_H
#define COLORMAP_API_H

#include <QtCore/qglobal.h>

#if defined(COLORMAP_LIBRARY)
#  define COLORMAP_API Q_DECL_EXPORT
#else
#  define COLORMAP_API Q_DECL_IMPORT
#endif

#endif // COLORMAP_API_H
