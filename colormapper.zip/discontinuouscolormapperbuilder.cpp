#include "discontinuouscolormapper.h"
#include "discontinuouscolormapperbuilder.h"

using namespace guimisc::colormapper;

DiscontinuousColorMapper DiscontinuousColorMapperBuilder::buildConstWidth(const ColorMapper& mapper, int numDivision)
{
	DiscontinuousColorMapper ret;
	double min = mapper.minValue();
	double max = mapper.maxValue();
	double delta = (max - min) / numDivision;

	ret.setDefaultColor(mapper.defaultColor());
	ret.setMinValue(min);

	for (int i = 1; i <= numDivision; ++i) {
		double value = min + delta * i;
		double valForC = value - delta * 0.5;
		QColor c = mapper.map(valForC);
		if (i == numDivision) {
			value = max;
		}
		ret.addRange(value, c);
	}
	return ret;
}
