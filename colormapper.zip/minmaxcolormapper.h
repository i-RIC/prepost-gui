#ifndef GUIMISC_MINMAXCOLORMAPPER_H
#define GUIMISC_MINMAXCOLORMAPPER_H

#include "colormap_api.h"
#include "colormapper.h"
#include "colormapper_enums.h"

#include <QColor>

namespace guimisc {
namespace colormapper {

class COLORMAP_API MinMaxColorMapper : public ColorMapper
{
public:
	MinMaxColorMapper(QColor::Spec spec, const QColor& colorMin, const QColor& colorMax);
	MinMaxColorMapper(double minValue, double maxValue, QColor::Spec, const QColor& colorMin, const QColor& colorMax);
	MinMaxColorMapper(const MinMaxColorMapper& mapper);
	MinMaxColorMapper(MinMaxColorMapper&& mapper);
	virtual ~MinMaxColorMapper();

	QColor map(double value) const override;
	QColor defaultColor() const override;
	double minValue() const override;
	double maxValue() const override;

	void setMinValue(double minValue);
	void setMaxValue(double maxValue);

	OutOfRangeMode outOfRangeMode() const;
	void setOutOfRangeMode(OutOfRangeMode mode);

	void setDefaultColor(const QColor& c);

	MinMaxColorMapper& operator=(const MinMaxColorMapper& mapper);
	MinMaxColorMapper& operator=(MinMaxColorMapper&& mapper);

private:
	class Impl;
	Impl* m_impl;
};

} // colormapper
} // guimisc

#ifdef _DEBUG
	#include "private/minmaxcolormapper_impl.h"
#endif // _DEBUG

#endif // GUIMISC_MINMAXCOLORMAPPER_H
