#ifndef GUIMISC_CONTINUOUSCOLORMAPPER_H
#define GUIMISC_CONTINUOUSCOLORMAPPER_H

#include "colormap_api.h"
#include "colormapper.h"
#include "colormapper_enums.h"

#include <QColor>

namespace guimisc {
namespace colormapper {

class COLORMAP_API ContinuousColorMapper : public ColorMapper
{
public:
	ContinuousColorMapper();
	ContinuousColorMapper(QColor::Spec spec);
	ContinuousColorMapper(const ContinuousColorMapper& mapper);
	ContinuousColorMapper(ContinuousColorMapper&& mapper);
	~ContinuousColorMapper();

	QColor map(double value) const override;
	QColor defaultColor() const override;
	double minValue() const override;
	double maxValue() const override;
	std::vector<double> values() const;

	OutOfRangeMode outOfRangeMode() const;
	void setOutOfRangeMode(OutOfRangeMode mode);

	void setDefaultColor(const QColor& c);

	void add(double value, const QColor& color);
	void remove(double value);
	void clear();

	ContinuousColorMapper& operator=(const ContinuousColorMapper& mapper);
	ContinuousColorMapper& operator=(ContinuousColorMapper&& mapper);

private:
	class Impl;
	Impl* m_impl;
};

} // colormapper
} // guimisc

#ifdef _DEBUG
	#include "private/continuouscolormapper_impl.h"
#endif // _DEBUG

#endif // GUIMISC_CONTINUOUSCOLORMAPPER_H
