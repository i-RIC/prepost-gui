#ifndef GUIMISC_COLORMAPPER_ENUMS_H
#define GUIMISC_COLORMAPPER_ENUMS_H

namespace guimisc {
namespace colormapper {

enum OutOfRangeMode {UseLimitColor, UseDefaultColor};

} // colormapper
} // guimisc


#endif // GUIMISC_COLORMAPPER_ENUMS_H

