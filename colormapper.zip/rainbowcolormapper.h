#ifndef GUIMISC_RAINBOWCOLORMAPPER_H
#define GUIMISC_RAINBOWCOLORMAPPER_H

#include "colormap_api.h"
#include "minmaxcolormapper.h"

namespace guimisc {
namespace colormapper {

class COLORMAP_API RainbowColorMapper : public MinMaxColorMapper
{
public:
	RainbowColorMapper();
	RainbowColorMapper(double min, double max);
	~RainbowColorMapper();
};

} // colormapper
} // guimisc

#endif // GUIMISC_RAINBOWCOLORMAPPER_H
