#include "grayscalecolormapper.h"

using namespace guimisc::colormapper;

GrayscaleColorMapper::GrayscaleColorMapper() :
	GrayscaleColorMapper(0, 1)
{}

GrayscaleColorMapper::GrayscaleColorMapper(double min, double max) :
	MinMaxColorMapper(min, max, QColor::Hsv, Qt::black, Qt::white)
{}

GrayscaleColorMapper::~GrayscaleColorMapper()
{}
