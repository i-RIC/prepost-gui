#include "rainbowcolormapper.h"

using namespace guimisc::colormapper;

RainbowColorMapper::RainbowColorMapper() :
	RainbowColorMapper(0, 1)
{}

RainbowColorMapper::RainbowColorMapper(double min, double max) :
	MinMaxColorMapper(min, max, QColor::Hsv, Qt::blue, Qt::red)
{}

RainbowColorMapper::~RainbowColorMapper()
{}
