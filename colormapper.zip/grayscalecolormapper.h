#ifndef GUIMISC_GRAYSCALECOLORMAPPER_H
#define GUIMISC_GRAYSCALECOLORMAPPER_H

#include "colormap_api.h"
#include "minmaxcolormapper.h"

namespace guimisc {
namespace colormapper {

class COLORMAP_API GrayscaleColorMapper : public MinMaxColorMapper
{
public:
	GrayscaleColorMapper();
	GrayscaleColorMapper(double min, double max);
	~GrayscaleColorMapper();
};

} // colormapper
} // guimisc

#endif // GUIMISC_GRAYSCALECOLORMAPPER_H
