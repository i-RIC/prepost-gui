#ifndef GUIMISC_MINMAXCOLORMAPPER_IMPL_H
#define GUIMISC_MINMAXCOLORMAPPER_IMPL_H

#include "../minmaxcolormapper.h"
#include "../continuouscolormapper.h"

namespace guimisc {
namespace colormapper {

class MinMaxColorMapper::Impl
{
public:
	Impl(QColor::Spec spec, const QColor& minColor, const QColor& maxColor);
	explicit Impl(const Impl& impl);
	~Impl();
	void update();

	Impl& operator=(const Impl& impl);

	double m_minValue;
	double m_maxValue;

	QColor m_minColor;
	QColor m_maxColor;

	ContinuousColorMapper* m_mapper;

	OutOfRangeMode m_outOfRangeMode;
	QColor m_defaultColor;
};

} // colormapper
} // guimisc

#endif // GUIMISC_MINMAXCOLORMAPPER_IMPL_H
