#ifndef GUIMISC_DISCONTINUOUSCOLORMAPPER_IMPL_H
#define GUIMISC_DISCONTINUOUSCOLORMAPPER_IMPL_H

#include "../discontinuouscolormapper.h"

#include <vector>

namespace guimisc {
namespace colormapper {

class DiscontinuousColorMapper::Impl
{
public:
	Impl();
	~Impl();

	std::vector<double> m_values;
	std::vector<QColor> m_colors;

	OutOfRangeMode m_outOfRangeMode;
	QColor m_defaultColor;
};

} // colormapper
} // guimisc


#endif // GUIMISC_DISCONTINUOUSCOLORMAPPER_IMPL_H

