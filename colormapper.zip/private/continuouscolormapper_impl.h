#ifndef GUIMISC_CONTINOUSCOLORMAPPER_IMPL_H
#define GUIMISC_CONTINOUSCOLORMAPPER_IMPL_H

#include "../continuouscolormapper.h"

#include <map>

namespace guimisc {
namespace colormapper {

class SpecHandler;

class ContinuousColorMapper::Impl
{
public:
	Impl(QColor::Spec spec);
	explicit Impl(const Impl& impl);
	~Impl();

	Impl& operator=(const Impl& impl);

	SpecHandler* m_specHandler;
	std::map<double, QColor> m_colorMap;

	OutOfRangeMode m_outOfRangeMode;
	QColor m_defaultColor;
};

} // colormapper
} // guimisc

#endif // CONTINOUSCOLORMAPPER_IMPL_H
