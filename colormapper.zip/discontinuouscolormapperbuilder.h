#ifndef GUIMISC_DISCONTINUOUSCOLORMAPPERBUILDER_H
#define GUIMISC_DISCONTINUOUSCOLORMAPPERBUILDER_H

#include "colormap_api.h"

namespace guimisc {
namespace colormapper {

class ColorMapper;
class DiscontinuousColorMapper;

class DiscontinuousColorMapperBuilder
{
public:
	static DiscontinuousColorMapper buildConstWidth(const ColorMapper& mapper, int numDivision);

private:
	DiscontinuousColorMapperBuilder();
};

} // colormapper
} // guimisc

#endif // GUIMISC_DISCONTINUOUSCOLORMAPPERBUILDER_H
