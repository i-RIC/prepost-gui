#ifndef GUIMISC_DISCONTINUOUSCOLORMAPPER_H
#define GUIMISC_DISCONTINUOUSCOLORMAPPER_H

#include "colormap_api.h"
#include "colormapper.h"
#include "colormapper_enums.h"

#include <QColor>

namespace guimisc {
namespace colormapper {

class COLORMAP_API DiscontinuousColorMapper : public ColorMapper
{
public:
	DiscontinuousColorMapper();
	DiscontinuousColorMapper(const DiscontinuousColorMapper& mapper);
	DiscontinuousColorMapper(DiscontinuousColorMapper&& mapper);
	~DiscontinuousColorMapper();

	QColor map(double value) const override;
	double minValue() const override;
	double maxValue() const override;
	std::vector<double> values() const;

	OutOfRangeMode outOfRangeMode() const;
	void setOutOfRangeMode(OutOfRangeMode mode);

	QColor defaultColor() const;
	void setDefaultColor(const QColor& c);

	void setMinValue(double minValue);
	void addRange(double value, const QColor& color);
	void clear();

	DiscontinuousColorMapper& operator=(const DiscontinuousColorMapper& mapper);
	DiscontinuousColorMapper& operator=(DiscontinuousColorMapper&& mapper);

private:
	class Impl;
	Impl* m_impl;
};

} // colormapper
} // guimisc

#ifdef _DEBUG
	#include "private/discontinuouscolormapper_impl.h"
#endif // _DEBUG

#endif // GUIMISC_DISCONTINUOUSCOLORMAPPER_H
