#ifndef GUIMISC_COLORMAPPER_H
#define GUIMISC_COLORMAPPER_H

#include "colormap_api.h"

class QColor;

namespace guimisc {
namespace colormapper {

class COLORMAP_API ColorMapper
{
public:
	virtual ~ColorMapper() {}
	virtual QColor map(double value) const = 0;
	virtual QColor defaultColor() const = 0;
	virtual double minValue() const = 0;
	virtual double maxValue() const = 0;
};

} // colormapper
} // guimisc

#endif // GUIMISC_COLORMAPPER_H
